import request from '@/utils/request'

//获取kplayer版本信息接口
// export function getKPlayerInfo() {
//   const url = '/dev-api/play/information'
//   const headers = {
//     'Content-Type': 'application/json'
//   }
//   return request({
//     url,
//     method: 'get',
//     headers
//   }).then(response => {
//     // 处理 API 响应数据
//     return response.data
//   }).catch(error => {
//     // 处理 API 异常
//     console.log(error)
//     throw error
//   })
// }
//获取完整列表接口
export function getResourceList() {
  const url = '/resource/list-all'
  const headers = {
    'Content-Type': 'application/json; charset=utf-8'
  }
  return axios.get(url, { headers }).then(response => {
    // 处理 API 响应数据
    return response.data
  }).catch(error => {
    // 处理 API 异常
    console.log(error)
    throw error
  })
}
