<template>

	<div>
		<el-card class="box-card">
			<el-button type="primary" @click="refresh">刷新</el-button>
			<el-button class="add-btn" type="primary" @click="dialogVisible = true">添加推流路径</el-button>
			<el-table :data="tableData" :pagination="true" :page-size="pageSize" :total="totalSize" border
				style="width: 100%;margin-top: 10px;">
				<el-table-column prop="path" label="推流路径" width="455">
				</el-table-column>
				<el-table-column prop="unique" label="唯一标识" width="80">
				</el-table-column>
				<el-table-column prop="create_time" label="创建时间" width="100">
					<template slot-scope="scope">{{ formatCreateTime(scope.row.create_time) }}</template>
				</el-table-column>
				<el-table-column prop="start_time" label="开始时间" width="110">
					<template slot-scope="scope">{{ formatStartTime(scope.row.start_time) }}</template>
				</el-table-column>
				<el-table-column prop="end_time" label="结束时间" width="110">
					<template slot-scope="scope">{{ formatEndTime(scope.row.end_time) }}</template>
				</el-table-column>
				<el-table-column prop="connected" label="连接状态" width="90">
				  <template slot-scope="scope">
				    <el-tag v-if="scope.row.connected" type="success">已连接</el-tag>
				    <el-tag v-else type="danger">连接失败</el-tag>
				  </template>
				</el-table-column>

				<el-table-column fixed="right" label="操作" width="100">
					<template slot-scope="scope">
						<el-link @click="handleClick(scope.row)" type="danger" style="margin-right: 13px;">删除</el-link>
						<el-link @click="linkClick" type="primary">跳转</el-link>
					</template>
				</el-table-column>
			</el-table>
		</el-card>

		<el-dialog title="资源时间跳转" :visible.sync="showForm">
			<el-form :model="formData" ref="form" :rules="rules" label-width="80px">
				<el-form-item label="唯一标识" prop="unique">
					<el-input v-model="formData.unique"></el-input>
				</el-form-item>
				<el-form-item label="跳转秒数" prop="seek">
					<el-input v-model="formData.seek"></el-input>
				</el-form-item>
				<el-form-item>
					<el-button type="primary" @click="submitseek">提交</el-button>
					<el-button @click="resetsForm">重置</el-button>
				</el-form-item>
			</el-form>
		</el-dialog>
		<el-dialog title="添加推流路径" :visible.sync="dialogVisible" width="30%">
			<el-form ref="resourceForm" :model="resource" label-width="100px" class="resource-form">
				<el-form-item label="推流路径" prop="output_path">
					<el-input v-model="resource.output_path"  placeholder="请输入推流路径"></el-input>
				</el-form-item>
				<el-form-item>
					<el-button type="primary" @click="submitForm">提交</el-button>
					<el-button @click="resetForm">重置</el-button>
				</el-form-item>
			</el-form>
		</el-dialog>
	</div>
</template>

<script>
	import Vue from 'vue';
	import axios from 'axios';
	export default {
		data() {
			return {
				// 每页数据条数
				pageSize: 5,
				// 当前页
				currentPage: 1,
				// 总数据条数
				totalSize: 100,
				// 显示在表格中的数据
				resourcelist: [], // 完整列表数据
				playingResource: null, // 当前正在播放的数据
				unplayedResources: [], // 未播放的数据
				tableData: [], // 表格数据
				dialogVisible: false,
				resource: {
					output_path: '',
				},
				showForm: false,
				formData: {
					unique: '',
					seek: ''
				},
				rules: {
					unique: [{
						required: true,
						message: '请输入Unique',
						trigger: 'blur'
					}],
					seek: [{
						required: true,
						message: '请输入Seek',
						trigger: 'blur'
					}]
				}
			}
		},
		mounted() {
			this.getResourceList();
		},
		methods: {
			// 将创建时间的时间戳转换为年月日字符串或者显示 "未开始"
			formatCreateTime(timestamp) {
				const date = new Date(timestamp * 1000);
				const year = date.getFullYear();
				const month = (date.getMonth() + 1).toString().padStart(2, '0');
				const day = date.getDate().toString().padStart(2, '0');
				return `${year}-${month}-${day}`;
			},
			
			// 将时间戳转换为年月日字符串或者显示 "未开始"
			formatStartTime(timestamp) {
				if (parseInt(timestamp) === 0) {
					return '未开始';
				}
				const date = new Date(parseInt(timestamp) * 1000);
				const year = date.getFullYear();
				const month = (date.getMonth() + 1).toString().padStart(2, '0');
				const day = date.getDate().toString().padStart(2, '0');
				return `${year}-${month}-${day}`;
			},
			// 将时间戳转换为年月日字符串或者显示 "未开始"
			formatEndTime(timestamp) {
				if (parseInt(timestamp) === 0) {
					return '暂无';
				}
				const date = new Date(parseInt(timestamp) * 1000);
				const year = date.getFullYear();
				const month = (date.getMonth() + 1).toString().padStart(2, '0');
				const day = date.getDate().toString().padStart(2, '0');
				return `${year}-${month}-${day}`;
			},
			// 重置表单
			resetForm() {
				this.$refs.resourceForm.resetFields();
			},
			// 重置表单
			resetsForm() {
				this.$refs.form.resetFields();
			},
			handleClick(row) {
				axios.delete('/dev-api/output/remove/' + row.unique)
					.then(response => {
						this.$message({
							message: '删除成功',
							type: 'success'
						});
						this.getResourceList();
					})
					.catch(error => {
						// 处理失败响应或异常
					 this.$message.error('删除失败，重新试试吧~');
					})
			},
			linkClick() {
				 window.open('https://link.bilibili.com/p/center/index?#/my-room/start-live');
			},
			//添加资源
			submitForm() {
				const url = this.$apiDev + "/output/add"
				axios.post(url, {
						output_path: this.resource.output_path,
					}, {
						headers: {
							'Content-Type': 'application/json; charset=utf-8'
						}
					})
					.then((response) => {
						// 请求成功的处理
						this.dialogVisible = false;
						// 关闭对话框
						this.$message({
							message: '添加成功',
							type: 'success'
						});
						this.getResourceList();
					})
					.catch((error) => {
					   this.$message.error('添加失败，重新试试吧~');
					});
			},
			//跳转资源
			submitseek() {


			},
			// 获取推流列表
			getResourceList() {
				axios.get('/dev-api/output/list')
					.then(response => {
						this.resourcelist = response.data.outputs;
						this.tableData=this.resourcelist;
					})
					.catch(error => {
						 this.$message.error('获取失败，重新试试吧~');
					});
			},
			// 刷新
			refresh() {
				this.getResourceList();
				this.$message({
					message: '刷新完成',
					type: 'success'
				});

			}
		},
	}
</script>
<style>
	.box-card {
		margin-top: 10px;
		margin-left: 30px;
		width: 1090px;
	}

	.page {
		padding-left: 20px;
		margin-top: 20px;
	}
</style>
