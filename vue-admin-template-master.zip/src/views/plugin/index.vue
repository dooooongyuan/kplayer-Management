<template>

	<div>
		<el-card class="box-card">
			<el-button type="primary" @click="refresh">刷新</el-button>
			<el-button class="add-btn" type="primary" @click="dialogVisible = true">添加插件</el-button>
			<el-table :data="tableData.slice((currentPage-1)*pageSize,currentPage*pageSize)" border
				style="width: 100%;margin-top: 10px;">
				<el-table-column prop="params.text" label="展示文本" width="180">
				</el-table-column>
				<el-table-column prop="unique" label="唯一标识" width="80">
				</el-table-column>
				<el-table-column prop="params.fontcolor" label="字体颜色" width="80">
				</el-table-column>
				<el-table-column prop="params.fontsize" label="字体大小" width="80">
				</el-table-column>
				<el-table-column prop="create_time" label="创建时间" width="100">
					<template slot-scope="scope">{{ formatCreateTime(scope.row.create_time) }}</template>
				</el-table-column>
				<el-table-column prop="loaded_time" label="加载时间" width="110">
					<template slot-scope="scope">{{ formatStartTime(scope.row.loaded_time) }}</template>
				</el-table-column>
				<el-table-column prop="params.x" label="x轴路径" width="80">
				</el-table-column>
				<el-table-column prop="params.y" label="y轴路径" width="80">
				</el-table-column>
				<el-table-column prop="path" label="插件路径" width="154">
				</el-table-column>
				<el-table-column fixed="right" label="操作" width="100">
					<template slot-scope="scope">
						<el-link @click="handleClick(scope.row)" type="danger" style="margin-right: 13px;">删除</el-link>
						<el-link @click="updateplugin(scope.row)" type="primary">修改</el-link>
					</template>
				</el-table-column>
			</el-table>
		</el-card>
		<!-- 分页 -->
		<el-pagination align='center' @size-change="handleSizeChange" @current-change="handleCurrentChange"
			:current-page="currentPage" :page-sizes="[1,5]" :page-size="pageSize"
			layout="total, sizes, prev, pager, next, jumper" :total="tableData.length" class="page">
		</el-pagination>
		<el-dialog title="修改插件" :visible.sync="showForm">
			<el-form :model="formData" ref="form" :rules="rules" label-width="80px">
				<el-form-item label="唯一标识" prop="unique">
					<el-input v-model="formData.unique" :disabled="true"></el-input>
				</el-form-item>
				<el-form-item label="展示文字" prop="params.text">
					<el-input v-model="formData.params.text"></el-input>
				</el-form-item>
				<el-form-item label="字体颜色" prop="params.fontcolor">
					<el-input v-model="formData.params.fontcolor"></el-input>
				</el-form-item>
				<el-form-item label="字体大小" prop="params.fontsize">
					<el-input v-model="formData.params.fontsize"></el-input>
				</el-form-item>
				<el-form-item label="x轴位置" prop="params.x">
					<el-input v-model="formData.params.x"></el-input>
				</el-form-item>
				<el-form-item label="y轴位置" prop="params.y">
					<el-input v-model="formData.params.y"></el-input>
				</el-form-item>
				<el-form-item>
					<el-button type="primary" @click="submitseek">提交</el-button>
					<el-button @click="resetsForm">重置</el-button>
				</el-form-item>
			</el-form>
		</el-dialog>
		<el-dialog title="添加插件" :visible.sync="dialogVisible" width="30%">
			<el-form ref="resourceForm" :model="resource" label-width="100px" class="resource-form" :rules="rule">
				<el-form-item label="唯一标识" prop="unique">
					<el-input v-model="resource.unique"></el-input>
				</el-form-item>
				<el-form-item label="展示文字" prop="params.text">
					<el-input v-model="resource.params.text"></el-input>
				</el-form-item>
				<el-form-item label="字体颜色" prop="params.fontcolor">
					<el-input v-model="resource.params.fontcolor"></el-input>
				</el-form-item>
				<el-form-item label="字体大小" prop="params.fontsize">
					<el-input v-model="resource.params.fontsize"></el-input>
				</el-form-item>
				<el-form-item label="x轴位置" prop="params.x">
					<el-input v-model="resource.params.x"></el-input>
				</el-form-item>
				<el-form-item label="y轴位置" prop="params.y">
					<el-input v-model="resource.params.y"></el-input>
				</el-form-item>
				<el-form-item>
					<el-button type="primary" @click="submitForm">提交</el-button>
					<el-button @click="resetForm">重置</el-button>
				</el-form-item>
			</el-form>
		</el-dialog>
	</div>
</template>

<script>
	import Vue from 'vue';
	import axios from 'axios';
	export default {
		data() {
			return {
				currentPage: 1, // 当前页码
				total: 100, // 总条数
				pageSize: 5, // 每页的数据条数
				// 显示在表格中的数据
				resourcelist: [], // 完整列表数据
				playingResource: null, // 当前正在播放的数据
				unplayedResources: [], // 未播放的数据
				tableData: [], // 表格数据
				dialogVisible: false,
				resource: {
					path: 'show-text',
					unique: '',
					params: {
						text: '',
						fontcolor: '',
						fontsize: '',
						x: '',
						y: ''
					}
				},
				showForm: false,
				formData: {
					path: 'show-text',
					unique: '',
					params: {
						text: '',
						fontcolor: '',
						fontsize: '',
						x: '',
						y: ''
					}
				},
				rules: {
					unique: [{
						required: true,
						message: '请输入Unique',
						trigger: 'blur'
					}]
				},
				rule: {
					unique: [{
						required: true,
						message: '请输入唯一标识，不能与现有标识相同',
						trigger: 'blur'
					}]
				}
			}
		},
		mounted() {
			this.getResourceList();
		},
		methods: {
			//每页条数改变时触发 选择一页显示多少行
			handleSizeChange(val) {
				this.currentPage = 1;
				this.pageSize = val;
			},
			//当前页改变时触发 跳转其他页
			handleCurrentChange(val) {
				this.currentPage = val;
			},
			// 将创建时间的时间戳转换为年月日字符串或者显示 "未开始"
			formatCreateTime(timestamp) {
				const date = new Date(timestamp * 1000);
				const year = date.getFullYear();
				const month = (date.getMonth() + 1).toString().padStart(2, '0');
				const day = date.getDate().toString().padStart(2, '0');
				return `${year}-${month}-${day}`;
			},

			// 将时间戳转换为年月日字符串或者显示 "未开始"
			formatStartTime(timestamp) {
				const date = new Date(parseInt(timestamp) * 1000);
				const year = date.getFullYear();
				const month = (date.getMonth() + 1).toString().padStart(2, '0');
				const day = date.getDate().toString().padStart(2, '0');
				return `${year}-${month}-${day}`;
			},
			// 重置表单
			resetForm() {
				this.$refs.resourceForm.resetFields();
			},
			// 重置表单
			resetsForm() {
				this.$refs.form.resetFields();
			},
			//删除插件
			handleClick(row) {
				axios.delete('/dev-api/plugin/remove/' + row.unique)
					.then(response => {
						this.$message({
							message: '删除成功',
							type: 'success'
						});
					})
					.catch(error => {
						this.$message.error('删除失败，重新试试吧~');
					})
			},
			updateplugin(row) {
				this.scope = row
				this.showForm = true
				Vue.nextTick(() => {
					this.formData.unique = row.unique;
					this.formData.params.text = row.params.text;
					this.formData.params.fontcolor = row.params.fontcolor;
					this.formData.params.fontsize = row.params.fontsize;
					this.formData.params.x = row.params.x;
					this.formData.params.y = row.params.y;
					this.$refs.form.clearValidate();
				});

			},
			//修改插件
			submitseek() {
				const url = this.$apiDev + "/plugin/update"
				axios.patch(url, {
						path: this.formData.path,
						unique: this.formData.unique,
						params: {
							text: this.formData.params.text,
							fontcolor: this.formData.params.fontcolor,
							fontsize: this.formData.params.fontsize,
							x: this.formData.params.x,
							y: this.formData.params.y,

						}
					}, {
						headers: {
							'Content-Type': 'application/json; charset=utf-8'
						}
					})
					.then((response) => {
						// 请求成功的处理
						this.showForm = false;
						// 关闭对话框
						this.$message({
							message: '修改成功',
							type: 'success'
						});

					})
					.catch((error) => {
						this.$message.error('修改失败，重新试试吧~');
					});
			},

			linkClick() {
				window.open('https://link.bilibili.com/p/center/index?#/my-room/start-live');
			},
			//添加资源
			submitForm() {
				const url = this.$apiDev + "/plugin/add"
				axios.post(url, {
						path: this.resource.path,
						unique: this.resource.unique,
						params: {
							text: this.resource.params.text,
							fontcolor: this.resource.params.fontcolor,
							fontsize: this.resource.params.fontsize,
							x: this.resource.params.x,
							y: this.resource.params.y,

						}
					}, {
						headers: {
							'Content-Type': 'application/json; charset=utf-8'
						}
					})
					.then((response) => {
						// 请求成功的处理
						this.dialogVisible = false;
						// 关闭对话框
						this.$message({
							message: '添加成功',
							type: 'success'
						});

					})
					.catch((error) => {
						this.$message.error('添加失败，重新试试吧~');
					});
			},
			// 获取插件列表
			getResourceList() {
				axios.get('/dev-api/plugin/list')
					.then(response => {
						this.resourcelist = response.data.plugins;
						this.tableData = this.resourcelist;

					})
					.catch(error => {
						this.$message.error('加载失败，重新试试吧~');
					});
			},
			// 刷新
			refresh() {
				this.getResourceList();
				this.$message({
					message: '刷新完成',
					type: 'success'
				});

			}
		},
	

	}
</script>
<style>
	.box-card {
		margin-top: 10px;
		margin-left: 30px;
		width: 1090px;
	}

	.page {
		margin-top: 20px;
		margin-right: 700px;
		
	}
</style>
