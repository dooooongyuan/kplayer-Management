<template>
	<div>
		<div class="card-container">
			<el-card class="box-card" style="flex: 1; margin-right: 10px;">
				<div slot="header" class="clearfix">
					<span>当前Kplayer版本信息</span>
				</div>
				<div style="font-size: 20px;">
					<span class="black-text"><i class="el-icon-cpu"
							style="color: royalblue;margin-right: 2px;"></i>主版本</span><span
						class="blue-text">{{playlist.major_version}}</span>
				</div>
				<div class="two">
					<span class="black-text">LibK播放器版本</span><span
						class="blue-text">{{playlist.libkplayer_version}}</span>
				</div>
				<div class="two">
					<span class="black-text">插件版本</span><span class="blue-text">{{playlist.plugin_version}}</span>
				</div>
				<div class="two">
					<span class="black-text">许可证版本</span><span class="blue-text">{{playlist.license_version}}</span>
				</div>
				<div class="two">
					<span class="black-text">开始时间</span><span class="blue-text">
						{{ formatDate(playlist.start_time) }}
					</span>
				</div>
				<div class="two">
					<span class="black-text">开始时间戳</span><span class="blue-text">
						{{new Date(playlist.start_time_timestamp * 1000).toLocaleString()}}
					</span>
				</div>
			</el-card>

			<el-card class="box-card" style="flex: 1; margin-right: 10px;">
				<div slot="header" class="clearfix">
					<span>直播间运行时长</span>
					<router-link to="/example/asset">
						<el-button style="float: right; padding: 3px 0" type="text">
							操作按钮
						</el-button>
					</router-link>
				</div>
				<div style="font-size: 20px;">
					<span class="black-text">开始时间</span>
					<span class="blue-text">
						{{new Date(playdurlist.start_timestamp * 1000).toLocaleString()}}
					</span>
				</div>
				<div class="two">
					<span class="black-text"><i class="el-icon-video-play"
							style="color: green;margin-right: 2px;"></i>运行时长</span>
					<span class="blue-text">
						{{ formattedTime }}
					</span>
				</div>
			</el-card>
			<el-card class="box-card" style="flex: 1;">
				<div slot="header" class="clearfix">
					<span>直播间编码信息</span>
				</div>
				<div style="font-size: 20px;">
					<span class="black-text">画面宽度</span><span class="blue-text">{{playencodelist.video_width}}</span>
				</div>
				<div class="two">
					<span class="black-text">画面高度</span><span class="blue-text">{{playencodelist.video_height}}</span>
				</div>
				<div class="two">
					<span class="black-text">视频帧率</span><span class="blue-text">{{playencodelist.video_fps}}<i
							style="margin-left: 8px;">Fps</i></span>
				</div>
				<div class="two">
					<span class="black-text">音频通道布局</span><span
						class="blue-text">{{playencodelist.audio_channel_layout}}</span>
				</div>
				<div class="two">
					<span class="black-text">音频采样率</span><span class="blue-text">{{playencodelist.audio_sample_rate}}<i
							style="margin-left: 8px;">Hz</i></span>
				</div>
				<div class="two">
					<span class="black-text">比特率</span><span class="blue-text">{{playencodelist.bit_rate}}<i
							style="margin-left: 8px;">bps</i></span>
				</div>
				<div class="two">
					<span class="black-text">平均质量</span><span class="blue-text">{{playencodelist.avg_quality}}</span>
				</div>
			</el-card>
		</div>
		<div class="tag-container">
			<el-tag closable @click.native="playVideo" style="
			    font-size: 24px;
			    padding: 20px 20px;
			    width: 180px;
			    height: 70px;
			    color: white;
				background-color: #67c23a; 
				margin-right: 30px;
			   " class="round-tag">继续播放<i class="el-icon-video-play" style="margin-left: 5px;"></i></el-tag>

			<el-tag closable @click.native="stopplayVideo" title="功能不稳定,谨慎使用!" style="
			       font-size: 24px;
			       padding: 20px 20px;
			       width: 180px;
			       height: 70px;
			       color: white;
			   	background-color: #f58220; 
				margin-right: 30px;
			      " class="round-tag-stop">暂停播放<i class="el-icon-video-pause" style="margin-left: 5px;"></i>

			</el-tag>

			<el-tag closable @click.native="skipplayVideo" style="
				      font-size: 24px;
				      padding: 20px 20px;
				      width: 180px;
				      height: 70px;
				      color: white;
				  	background-color: #999d9c; 
					margin-right: 30px;
				     " class="round-tag">跳过播放<i class="el-icon-d-arrow-right" style="margin-left: 5px;"></i></el-tag>
			<el-tag closable title="功能暂不可用!" style="
					 	      font-size: 24px;
					 	      padding: 20px 20px;
					 	      width: 180px;
					 	      height: 70px;
					 	      color: white;
							  margin-right: 30px;
					 	  	background-color: #f15b6c; 
					 	     " class="round-tag-stop2">停止播放<i class="el-icon-switch-button" style="margin-left: 5px;"></i></el-tag>
			<el-tag closable @click="dialogFormVisible = true" style="
							 		 	      font-size: 24px;
							 		 	      padding: 20px 20px;
							 		 	      width: 180px;
							 		 	      height: 70px;
							 		 	      color: white;
							 		 	  	background-color: #4e72b8; 
							 		 	     " class="round-tag">更改质量<i class="el-icon-video-camera-solid" style="margin-left: 5px;"></i></el-tag>
		</div>
		<!-- 更改质量表单 -->
		<el-dialog title="更改当前编码平均质量" :visible.sync="dialogFormVisible">
			<el-form :model="form">
				<el-form-item label="平均质量" :label-width="formLabelWidth">
					<el-input v-model="form.avg_quality" placeholder="请填写数字" autocomplete="off"></el-input>
				</el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="dialogFormVisible = false">取 消</el-button>
				<el-button type="primary" @click="encode">确 定</el-button>
			</div>
		</el-dialog>
	</div>
</template>


<script>
	import Vue from 'vue'
	import axios from 'axios';
	import main from '@/main.js';
	import Meta from 'vue-meta';

	Vue.use(Meta);
	import {
		mapGetters
	} from 'vuex'
	import {
		getKPlayerInfo
	} from '@/api/kplayer'

	export default {
		name: 'Dashboard',
		metaInfo: {
			meta: [{
					name: 'viewport',
					content: 'width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no'
				},
				// 其他的 meta 属性
			]
		},
		
		data() {
			return {
				playlist: {},
				playdurlist: {},
				playencodelist: {},
				dialogFormVisible: false,
				form: {
					avg_quality: ''
				},
				formLabelWidth: '150px'

			};

		},
		computed: {
			...mapGetters([
				'name'
			]),
			formattedTime() {
				const hours = Math.floor(this.playdurlist.duration_timestamp / 3600);
				const minutes = Math.floor((this.playdurlist.duration_timestamp - hours * 3600) / 60);
				const seconds = this.playdurlist.duration_timestamp % 60;
				return hours.toString().padStart(2, '0') + '时' +
					minutes.toString().padStart(2, '0') + '分' +
					seconds.toString().padStart(2, '0') + '秒';
			}
		},
		mounted() {
			this.fetchKPlayerInfo();
			this.playduration();
			this.playencode();
		},
		methods: {
			//继续播放
			playVideo() {
				axios.post('/dev-api/play/continue', {})
					.then((response) => {
						console.log(response.data);
						this.$message({
							message: '正在播放视频~稍等',
							type: 'success'
						});
					})
					.catch((error) => {
						console.log(error);
					});
			},
			//暂停播放
			stopplayVideo() {
				axios.post('/dev-api/play/pause', {})
					.then((response) => {
						console.log(response.data);
						this.$message({
							message: '视频已暂停',
							type: 'warning'
						});
					})
					.catch((error) => {
						console.log(error);
					});
			},
			//跳过播放
			skipplayVideo() {
				axios.post('/dev-api/play/skip', {})
					.then((response) => {
						console.log(response.data);
						this.$message({
							message: '正在切换下一条视频~稍等',
							type: 'success'
						});
					})
					.catch((error) => {
						console.log(error);
					});
			},
			//更改当前编码平均质量
			encode() {
				const url = this.$apiDev + "/play/encode/avg_quality"
				axios.post(url, {
						avg_quality: this.form.avg_quality,
					}, {
						headers: {
							'Content-Type': 'application/json; charset=utf-8'
						}
					})
					.then((response) => {
						console.log(response.data);
						// 请求成功的处理
						this.dialogFormVisible = false;
						// 关闭对话框
						this.$message({
							message: '切换成功',
							type: 'success'
						});
					})
					.catch((error) => {
						this.$message.error('切换失败，再试试看吧~');
					});
			},
			// 转换时间格式的方法
			formatDate: function(timestamp) {
				const datetime = timestamp.split('.')[0] // 截取到秒
				return datetime.replace(' ', 'T') // 转换成ISO 8601格式，便于移动端兼容性
			},
			//获取kplayer版本信息
			fetchKPlayerInfo() {
				axios.get('/dev-api/play/information')
					.then(response => {
						// 在这里处理接口请求成功后返回的数据
						this.playlist = response.data;

					})
					.catch(error => {
						// 在这里处理接口请求失败后的情况
						console.error(error);
						this.$notify({
							title: '提示',
							message: '未开启kplayer,请尝试开启并重新进入此页',
							duration: 0
						});
					});
			},
			//获取直播间运行时长
			playduration() {
				axios.get('/dev-api/play/duration')
					.then(response => {
						// 在这里处理接口请求成功后返回的数据
						this.playdurlist = response.data;

					})
					.catch(error => {
						// 在这里处理接口请求失败后的情况
						this.$message.error('获取失败，再试试看吧~');
					});
			},
			//获取直播间编码信息
			playencode() {
				axios.get('/dev-api/play/encode')
					.then(response => {
						// 在这里处理接口请求成功后返回的数据
						this.playencodelist = response.data;

					})
					.catch(error => {
						// 在这里处理接口请求失败后的情况
						this.$message.error('获取失败，再试试看吧~');
					});
			}
		}
	}
</script>

<style>
	.round-tag-stop2 {
		position: relative;
	}

	.round-tag-stop2:hover:before {
		content: attr(title);
		position: absolute;
		top: 100%;
		left: 50%;
		transform: translateX(-50%);
		padding: 6px 10px;
		margin-top: 20px;
		background-color: #f15b6c;
		color: white;
		border-radius: 4px;
		font-size: 20px;
		white-space: nowrap;
	}

	.round-tag-stop {
		position: relative;
	}

	.round-tag-stop:hover:before {
		content: attr(title);
		position: absolute;
		top: 100%;
		left: 50%;
		transform: translateX(-50%);
		padding: 6px 10px;
		margin-top: 20px;
		background-color: #f58220;
		color: white;
		border-radius: 4px;
		font-size: 20px;
		white-space: nowrap;
	}

	.tag-container {
		margin-left: 15px;
		margin-top: 30px;
		display: flex;
		flex-wrap: wrap;
		/* justify-content: center; */

	}

	@media screen and (max-width: 768px) {
		.card-container {
			flex-direction: column;
		}

		.box-card {
			margin: 10px;
		}

		.two {
			flex-direction: column;
		}
	}

	.round-tag .el-tag__close {
		display: none;
	}

	.round-tag-stop .el-tag__close {
		display: none;
	}

	.round-tag-stop2 .el-tag__close {
		display: none;
	}

	.round-tag-stop {
		border-radius: 10px;
		margin-right: 5px;
	}

	.round-tag-stop2 {
		border-radius: 10px;
		margin-right: 5px;
	}

	.round-tag {
		border-radius: 10px;
		margin-right: 5px;
	}

	.two {
		font-size: 20px;
		margin-top: 10px;
		display: flex;
		flex-wrap: wrap;

	}

	.black-text {
		color: #303133;
	}

	.blue-text {
		padding-left: 15px;
		color: #3366CC;
	}

	.text {
		font-size: 14px;
	}

	.item {
		margin-bottom: 18px;
	}

	.clearfix:before,
	.clearfix:after {
		display: table;
		content: "";
	}

	.clearfix:after {
		clear: both
	}

	.box-card {
		flex: 1;
		margin-top: 20px;
		margin-left: 10px;
		margin-right: 10px;
	}

	.card-container {
		display: flex;
		flex-wrap: wrap;
		margin: 10px;
	}
</style>
