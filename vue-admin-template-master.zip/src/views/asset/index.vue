<template>

	<div>
		<el-card class="box-card">
			<el-button type="primary" @click="refresh">刷新</el-button>
			<el-button class="add-btn" type="primary" @click="dialogVisible = true">添加资源</el-button>
			<el-table :data="tableData.slice((currentPage-1)*pageSize,currentPage*pageSize)"  border
				style="width: 100%;margin-top: 10px;" >
				<el-table-column prop="path" label="资源文件路径" width="290">
				</el-table-column>
				<el-table-column prop="unique" label="唯一标识" width="80">
				</el-table-column>
				<el-table-column prop="seek" label="起始播放" width="80">
				</el-table-column>
				<el-table-column prop="end" label="结束播放" width="80">
				</el-table-column>
				<el-table-column prop="create_time" label="创建时间" width="100">
					<template slot-scope="scope">{{ formatCreateTime(scope.row.create_time) }}</template>
				</el-table-column>
				<el-table-column prop="start_time" label="开始时间" width="110">
					<template slot-scope="scope">{{ formatStartTime(scope.row.start_time) }}</template>
				</el-table-column>
				<el-table-column prop="end_time" label="结束时间" width="110">
					<template slot-scope="scope">{{ formatEndTime(scope.row.end_time) }}</template>
				</el-table-column>
	
				<el-table-column prop="status" label="运行状态">
					<template slot-scope="scope">
						<el-tag :type="getStatusType(scope.row.status)">
							{{ getStatusText(scope.row.status) }}
						</el-tag>
					</template>
				</el-table-column>

				<el-table-column fixed="right" label="操作" width="100">
					<template slot-scope="scope">
						<el-link @click="handleClick(scope.row)" type="danger" style="margin-right: 13px;">删除</el-link>
						<el-link @click="linkClick(scope.row)" type="primary">跳转</el-link>
					</template>
				</el-table-column>
			</el-table>
			<!-- 分页 -->
			<el-pagination align='center' @size-change="handleSizeChange" @current-change="handleCurrentChange"
				:current-page="currentPage" :page-sizes="[1,5]" :page-size="pageSize"
				layout="total, sizes, prev, pager, next, jumper" :total="tableData.length" class="page">
			</el-pagination>
		</el-card>

		<el-dialog title="资源时间跳转"  :visible.sync="showForm">
			<el-form :model="formData" ref="form" :rules="rule" label-width="80px">
				<el-form-item label="唯一标识" prop="unique">
					<el-input v-model="formData.unique"></el-input>
				</el-form-item>
				<el-form-item label="跳转秒数" prop="seek">
					<el-input v-model="formData.seek"></el-input>
				</el-form-item>
				<el-form-item>
					<el-button type="primary" @click="submitseek">提交</el-button>
					<el-button @click="resetsForm">重置</el-button>
				</el-form-item>
			</el-form>
		</el-dialog>
		<el-dialog title="添加资源" :visible.sync="dialogVisible" width="50%">
			<el-form ref="resourceForm" :model="resource" label-width="100px" class="resource-form" :rules="rules">
				<el-form-item label="唯一标识" prop="unique">
					<el-input v-model="resource.unique" placeholder="请输入唯一标识,随意英文字母"></el-input>
				</el-form-item>
				<el-form-item label="资源路径" prop="path">
					<el-input v-model="resource.path" placeholder="请输入资源路径,对应你的服务器资源存放路径"></el-input>
				</el-form-item>
				<el-form-item>
					<el-button type="primary" @click="submitForm">提交</el-button>
					<el-button @click="resetForm">重置</el-button>
				</el-form-item>
			</el-form>
		</el-dialog>
	</div>
</template>

<script>
	import Vue from 'vue';
	import axios from 'axios';
	import Meta from 'vue-meta';
	Vue.use(Meta);
	export default {
		metaInfo: {
			meta: [{
					name: 'viewport',
					content: 'width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no'
				},
				// 其他的 meta 属性
			]
		},
		data() {
			return {
				currentPage: 1, // 当前页码
				total: 100, // 总条数
				pageSize: 5 ,// 每页的数据条数
				
				// 显示在表格中的数据
				resourcelist: [], // 完整列表数据
				playingResource: null, // 当前正在播放的数据
				unplayedResources: [], // 未播放的数据
				tableData: [
					   
				], // 表格数据
				dialogVisible: false,
				resource: {
					path: '',
					unique: '',
				},
				showForm: false,
				formData: {
					unique: '',
					seek: ''
				},
				
				rule: {
					seek: [{
						required: true,
						message: '请输入视频跳转的时间，单位（秒）',
						trigger: 'blur'
					}]
				},
				rules: {
					unique: [{
						required: true,
						message: '请输入唯一标识，不能与现有标识相同',
						trigger: 'blur'
					}],
				}
			}
		},
		
		mounted() {
			this.getResourceList();
		},
		methods: {
			//每页条数改变时触发 选择一页显示多少行
			handleSizeChange(val) {
				this.currentPage = 1;
				this.pageSize = val;
			},
			//当前页改变时触发 跳转其他页
			handleCurrentChange(val) {
				this.currentPage = val;
			},
			// 重置表单
			resetForm() {
				this.$refs.resourceForm.resetFields();
			},
			
			// 重置表单
			resetsForm() {
				this.$refs.form.resetFields();
			},
			// 获取状态对应的文本
			getStatusText(status) {
				switch (status) {
					case '未播放':
						return '未播放';
					case '正在播放':
						return '正在播放';
					case '已播放':
						return '已播放';
					default:
						return '未知';
				}
			},
			// 获取状态对应的标签类型名称
			getStatusType(status) {
				switch (status) {
					case '未播放':
						return 'info';
					case '正在播放':
						return 'success';
					case '已播放':
						return '';
					default:
						return 'warning';
				}
			},
			// 将创建时间的时间戳转换为年月日字符串或者显示 "未开始"
			formatCreateTime(timestamp) {
				const date = new Date(timestamp * 1000);
				const year = date.getFullYear();
				const month = (date.getMonth() + 1).toString().padStart(2, '0');
				const day = date.getDate().toString().padStart(2, '0');
				return `${year}-${month}-${day}`;
			},

			// 将时间戳转换为年月日字符串或者显示 "未开始"
			formatStartTime(timestamp) {
				if (parseInt(timestamp) === 0) {
					return '未开始';
				}
				const date = new Date(parseInt(timestamp) * 1000);
				const year = date.getFullYear();
				const month = (date.getMonth() + 1).toString().padStart(2, '0');
				const day = date.getDate().toString().padStart(2, '0');
				return `${year}-${month}-${day}`;
			},
			// 将时间戳转换为年月日字符串或者显示 "未开始"
			formatEndTime(timestamp) {
				if (parseInt(timestamp) === 0) {
					return '暂无';
				}
				const date = new Date(parseInt(timestamp) * 1000);
				const year = date.getFullYear();
				const month = (date.getMonth() + 1).toString().padStart(2, '0');
				const day = date.getDate().toString().padStart(2, '0');
				return `${year}-${month}-${day}`;
			},
			handleClick(row) {
				axios.delete('/dev-api/resource/remove/' + row.unique)
					.then(response => {
						this.$message({
							message: '删除成功',
							type: 'success'
						});
						this.getResourceList();
					})
					.catch(error => {
						  this.$message.error('删除失败，重新试试吧~');
					})
			},
			linkClick(row) {
				this.scope = row
				this.showForm = true
				Vue.nextTick(() => {
				  this.formData.unique = row.unique;
				  this.formData.seek = '';
				  this.$refs.form.clearValidate();
				});

			},
			//添加资源
			submitForm() {
				const url = this.$apiDev + "/resource/add"
				axios.post(url, {
						path: this.resource.path,
						unique: this.resource.unique
					}, {
						headers: {
							'Content-Type': 'application/json; charset=utf-8'
						}
					})
					.then((response) => {
						// 请求成功的处理
						this.dialogVisible = false;
						// 关闭对话框
						this.$message({
							message: '添加成功',
							type: 'success'
						});
						this.getResourceList();
					})
					.catch((error) => {
					   this.$message.error('添加失败，重新试试吧~');
					});
			},
			//跳转资源
			submitseek(){
				const url = this.$apiDev + "/resource/seek"
				axios.post(url, {
						unique: this.formData.unique,
						seek: this.formData.seek
					}, {
						headers: {
							'Content-Type': 'application/json; charset=utf-8'
						}
					})
					.then((response) => {
						// 请求成功的处理
						this.showForm = false;
						// 关闭对话框
						this.$message({
							message: '执行成功',
							type: 'success'
						});
						
					})
					.catch((error) => {
						  this.$message.error('跳转失败，重新试试吧~');
					});
			},
			// 获取完整列表
			getResourceList() {
				axios.get('/dev-api/resource/list-all')
					.then(response => {
						this.resourcelist = response.data.resources;
						this.getPlayingResource();
						
					})
					.catch(error => {
						  this.$message.error('获取失败，重新试试吧~');
					});
				
			},
			// 获取正在播放的数据
			getPlayingResource() {
				axios.get('/dev-api/resource/current')
					.then(response => {
						this.playingResource = response.data.resource;
						// 当播放资源改变时触发对比
						this.compareResources();
					})
					.catch(error => {
						console.error(error);
					});
			},
			// 获取未播放的数据
			getUnplayedResources() {
				axios.get('/dev-api/resource/list')
					.then(response => {
						this.unplayedResources = response.data.resources;
						// 当未播放资源改变时触发对比
						this.compareResources();
					})
					.catch(error => {
						console.error(error);
					});
			},
			// 数据对比
			compareResources() {
				this.tableData = this.resourcelist.map(resource => {
					if (this.playingResource && resource.unique === this.playingResource.unique) {
						resource.status = '正在播放';
					} else if (this.unplayedResources.some(unplayedResource => unplayedResource.unique === resource
							.unique)) {
						resource.status = '已播放';
					} else {
						resource.status = '未播放';
					}
					return resource;
				});
			},
		

			// 刷新
			refresh() {
				this.getResourceList();
				this.$message({
					message: '刷新完成',
					type: 'success'
				});

			}
		},
		
	}
</script>
<style>
	.box-card {
		margin-top: 10px;
		margin-left: 30px;
		width: 1090px;
	}

	.page {
		margin-top: 20px;
		margin-right: 620px;
		
	}
	
</style>
