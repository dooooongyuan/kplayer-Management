package com.kplayer.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import java.io.IOException;

@RestController
@CrossOrigin
public class PlayController {
    @Value("${myapp.server.url}")
    private String serverUrl;

    /**
     * 显示kplayer版本信息
     */
    @GetMapping("/play/information")
    public String getInfo() {
        String url = serverUrl +"/play/information";
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer xxxxxxxxx"); // 设置 Authorization 请求头
        headers.set("Content-Type", "application/json"); // 设置 Content-Type 请求头
        HttpEntity<String> entity = new HttpEntity<>(headers);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
        return response.getBody();
    }
    /**
     * 获取运行时长
     */
    @GetMapping("/play/duration")
    public String getPlayDuration() throws IOException {
        String url = serverUrl +"/play/duration";
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .build();

        try (Response response = client.newCall(request).execute()) {
            return response.body().string();
        } catch (IOException e) {
            return e.getMessage();
        }
    }
    /**
     * 暂停播放
     */
    @PostMapping("/play/pause")
    public String postPlayPause() {
        String url = serverUrl +"/play/pause";
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json; charset=utf-8"); // 设置 Content-Type 请求头
        String requestBody = "{}";
        HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
        return response.getBody();
    }
    /**
     * 继续播放
     */
    @PostMapping("/play/continue")
    public String postPlayContinue() {
        String url = serverUrl +"/play/continue";
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json; charset=utf-8"); // 设置 Content-Type 请求头
        HttpEntity<String> entity = new HttpEntity<>("{}", headers);
        ResponseEntity<String> response = restTemplate.postForEntity(url, entity, String.class);
        return response.getBody();
    }
    /**
     * 跳过当前播放资源
     */
    @PostMapping("/play/skip")
    public String postPlaySkip() {
        String url = serverUrl +"/play/skip";
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json; charset=utf-8"); // 设置 Content-Type 请求头
        HttpEntity<String> entity = new HttpEntity<>("{}", headers);
        ResponseEntity<String> response = restTemplate.postForEntity(url, entity, String.class);
        return response.getBody();
    }
    /**
     * 获取当前编码信息
     */
    @GetMapping("/play/encode")
    public String getEncode() {
        String url = serverUrl +"/play/encode";
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, null, String.class);
        return response.getBody();
    }
    /**
     * 更改当前编码平均质量
     */

    @PostMapping("/play/encode/avg_quality")
    public String postEncodeAvgQuality(@RequestBody String requestBody) {
        String url = serverUrl +"/play/encode/avg_quality";
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json; charset=utf-8"); // 设置 Content-Type 请求头
        HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);
        ResponseEntity<String> response = restTemplate.postForEntity(url, entity, String.class);
        return response.getBody();
    }
}
