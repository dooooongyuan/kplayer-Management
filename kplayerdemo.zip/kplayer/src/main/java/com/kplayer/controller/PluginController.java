package com.kplayer.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPatch;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;

@RestController
@CrossOrigin
public class PluginController {
    @Value("${myapp.server.url}")
    private String serverUrl;
    /**
     * 添加插件资源
     */
    @PostMapping("/plugin/add")
    public String postPluginAdd(@RequestBody Map<String, Object> requestMap) throws JsonProcessingException {
        String url = serverUrl + "/plugin/add";
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

        // 获取请求体中的参数并动态设置
        Map<String, Object> requestBody = new HashMap<>();
        for (Map.Entry<String, Object> entry : requestMap.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            if (key.equals("params")) {
                // 如果是 params 对象，则动态修改其中的 text 值
                Map<String, String> params = (Map<String, String>) value;
                // 动态设置 text 的值

                // 动态添加其他参数键值对
                params.put("otherParam", "otherValue");
            }
            requestBody.put(key, value);
        }

        // 将对象转换为 JSON 字符串
        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(requestBody);

        HttpEntity<String> requestEntity = new HttpEntity<>(json, headers);
        ResponseEntity<String> responseEntity = restTemplate.postForEntity(url, requestEntity, String.class);
        return responseEntity.getBody();
    }



    /**
     *获取插件列表
     */
    @GetMapping("/plugin/list")
    public String getPluginList() {
        String url = serverUrl + "/plugin/list";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        HttpEntity<String> requestEntity = new HttpEntity<>("{}", headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.GET, requestEntity, String.class);
        String responseBody = responseEntity.getBody();
        return responseBody;
    }

    /**
     * 更新插件参数
     * @param
     * @return
     */
    @PatchMapping("/plugin/update")
    public String postPluginUpdate(@RequestBody Map<String, Object> requestMap) throws JsonProcessingException, IOException {
        String url = serverUrl + "/plugin/update";
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpPatch httpPatch = new HttpPatch(url);
        httpPatch.addHeader("Content-Type", "application/json;charset=utf-8");
        // 获取请求体中的参数并动态设置
        Map<String, Object> requestBody = new HashMap<>();
        for (Map.Entry<String, Object> entry : requestMap.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            if (key.equals("params")) {
                // 如果是 params 对象，则动态修改其中的 text 值
                Map<String, String> params = (Map<String, String>) value;
                // 动态设置 text 的值
                // 动态添加其他参数键值对
                params.put("otherParam", "otherValue");
            }
            requestBody.put(key, value);
        }
        // 将请求体转换为 JSON 字符串
        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(requestBody);
        StringEntity entity = new StringEntity(json, Charset.forName("UTF-8"));
        httpPatch.setEntity(entity);
        CloseableHttpResponse response = httpClient.execute(httpPatch);
        String result = "";
        org.apache.http.HttpEntity responseEntity = response.getEntity();
        if (responseEntity != null) {
            result = EntityUtils.toString(responseEntity, Charset.forName("UTF-8"));
        }
        response.close();
        httpClient.close();
        return result;
    }

    /**
     * 删除插件
     */
    @DeleteMapping("/plugin/remove/{unique}")
    public String removePlugin(@PathVariable String unique) {
        String url = serverUrl + "/plugin/remove/" + unique;
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        HttpEntity<String> requestEntity = new HttpEntity<>("{}", headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.DELETE, requestEntity, String.class);
        String responseBody = responseEntity.getBody();
        return responseBody;
    }

}
