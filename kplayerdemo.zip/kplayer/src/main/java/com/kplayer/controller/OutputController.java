package com.kplayer.controller;



import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@RestController
@CrossOrigin
public class OutputController {
    @Value("${myapp.server.url}")
    private String serverUrl;
    /**
     * 添加输出资源
     */
    @PostMapping("/output/add")
    public String postOutputAdd(@RequestBody JSONObject requestBody) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        HttpEntity<String> requestEntity = new HttpEntity<>(requestBody.toString(), headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> responseEntity = restTemplate.postForEntity(serverUrl, requestEntity, String.class);
        String responseBody = responseEntity.getBody();
        return responseBody;
    }
    /**
     * 删除输出资源
     */
    @DeleteMapping("/output/remove/{unique}")
    public String deleteOutput(@PathVariable String unique) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        HttpEntity<String> requestEntity = new HttpEntity<>("{}", headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> responseEntity = restTemplate.exchange(serverUrl +unique, HttpMethod.DELETE, requestEntity, String.class);
        String responseBody = responseEntity.getBody();
        return responseBody;
    }
    /**
     *获取输出资源列表
     */
    @GetMapping("/output/list")
    public String getOutputList() {
        String url = serverUrl + "/output/list";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        HttpEntity<String> requestEntity = new HttpEntity<>("{}", headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.GET, requestEntity, String.class);
        String responseBody = responseEntity.getBody();
        return responseBody;
    }



}
