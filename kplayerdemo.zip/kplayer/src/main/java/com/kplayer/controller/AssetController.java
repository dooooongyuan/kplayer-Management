package com.kplayer.controller;



//import okhttp3.internal.http.HttpHeaders;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@CrossOrigin()
public class AssetController {
    @Value("${myapp.server.url}")
    private String serverUrl;
    /**
     * 增加输入资源
     */

    @PostMapping("/resource/add")
    public String addResource(@RequestBody Map<String, String> requestMap) {
        String url = serverUrl +"/resource/add";
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        HttpEntity<Map<String, String>> requestEntity = new HttpEntity<>(requestMap, headers);
        ResponseEntity<String> responseEntity = restTemplate.postForEntity(url, requestEntity, String.class);
        return responseEntity.getBody();
    }

    /**
     * 获取完整列表资源
     */
    @GetMapping("/resource/list-all")
    public String getResourceList() {
        String url = serverUrl + "/resource/list-all";
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json; charset=utf-8"); // 设置 Content-Type 请求头
        HttpEntity<String> entity = new HttpEntity<>("", headers);
        ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);
        return response.getBody();
    }
    /**
     *获取未播放列表
     */
    @GetMapping("/resource/list")
    public String getResource() {
        String url = serverUrl +"/resource/list";
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json; charset=utf-8");
        HttpEntity<String> entity = new HttpEntity<>("", headers);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
        return response.getBody();
    }
    /**
     * 获取当前播放资源
     */
    @GetMapping("/resource/current")
    public String getCurrentResource() {
        String url = serverUrl +"/resource/current";
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json; charset=utf-8");
        HttpEntity<String> entity = new HttpEntity<>("", headers);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
        return response.getBody();
    }
    /**
     * 删除输入资源
     */

    @DeleteMapping("/resource/remove/{unique}")
    public String removeResource(@PathVariable String unique) {
        String url = serverUrl +"/resource/remove/";
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json; charset=utf-8");
        HttpEntity<String> entity = new HttpEntity<>("", headers);
        ResponseEntity<String> response = restTemplate.exchange(url + unique, HttpMethod.DELETE, entity, String.class);
        return response.getBody();
    }
    /**
     * 资源时间跳转
     */
    @PostMapping("/resource/seek")
    public String seekResource(@RequestBody Map<String, Object> reqBody) throws JSONException {
        String url = serverUrl +"/resource/seek";
        String unique = reqBody.get("unique").toString();
        String seek = reqBody.get("seek").toString();
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json; charset=utf-8");
        JSONObject requestJson = new JSONObject();
        requestJson.put("unique", unique);
        requestJson.put("seek", seek);
        String requestBody = requestJson.toString();
        HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
        return response.getBody();
    }

}
